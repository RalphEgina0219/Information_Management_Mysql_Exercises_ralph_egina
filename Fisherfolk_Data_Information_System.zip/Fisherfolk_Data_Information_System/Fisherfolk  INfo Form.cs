﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Fisherfolk_Data_Information_System
{
    public partial class Fisherfolk__INfo_Form : Form


    {
        string connectionString = "server=localhost;database=fisherfolk_db;uid=root;pwd=yourpassword;";

        public Fisherfolk__INfo_Form()
        {
            InitializeComponent();
        }
        private void LoadData()
        {
            using (MySqlConnection con = new MySqlConnection(connectionString))
            {
                con.Open();
                string query = "SELECT * FROM fisherfolk";
                MySqlDataAdapter da = new MySqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvFisherfolk.DataSource = dt;
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Fisherfolk__INfo_Form_Load(object sender, EventArgs e)
        {
         
        }

        private void txtAge_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {

        }

        private void button15_Click(object sender, EventArgs e)
        {
            
        }

        private void button7_Click(object sender, EventArgs e)
        {

        }

        private void dgvFisherfolk_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnADD_Click(object sender, EventArgs e)
        {
            using (MySqlConnection con = new MySqlConnection(connectionString))
            {
                con.Open();
                string query = "INSERT INTO fisherfolk (full_name, age, gender, address, contact_no) VALUES (@name, @age, @gender, @address, @contact)";
                MySqlCommand cmd = new MySqlCommand(query, con);
                cmd.Parameters.AddWithValue("@name", txtName.Text);
                cmd.Parameters.AddWithValue("@age", txtAge.Text);
                cmd.Parameters.AddWithValue("@gender", cbGender.SelectedItem.ToString());
                cmd.Parameters.AddWithValue("@address", txtAddress.Text);
                cmd.Parameters.AddWithValue("@contact", txtContact.Text);

                cmd.ExecuteNonQuery();
                MessageBox.Show("Fisherfolk Added Successfully!");
                LoadData();

               

            }
            txtName.Clear();
            txtAge.Clear();
            cbGender.Items.Clear();
            txtAddress.Clear();
            txtContact.Clear();

        }

        private void btnUPDATE_Click(object sender, EventArgs e)
        {
            if (dgvFisherfolk.CurrentRow != null)
            {
                try
                {
                    int id = Convert.ToInt32(dgvFisherfolk.CurrentRow.Cells["fisher_id"].Value);

                    using (MySqlConnection con = new MySqlConnection(connectionString))
                    {
                        con.Open();
                        string query = "UPDATE fisherfolk SET full_name=@name, age=@age, gender=@gender, address=@address, contact_no=@contact WHERE fisher_id=@id";
                        MySqlCommand cmd = new MySqlCommand(query, con);

                        cmd.Parameters.AddWithValue("@name", txtName.Text);
                        cmd.Parameters.AddWithValue("@age", int.Parse(txtAge.Text));
                        cmd.Parameters.AddWithValue("@gender", cbGender.Text);
                        cmd.Parameters.AddWithValue("@address", txtAddress.Text);
                        cmd.Parameters.AddWithValue("@contact", txtContact.Text);
                        cmd.Parameters.AddWithValue("@id", id);

                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                            MessageBox.Show("Record updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        else
                            MessageBox.Show("No record updated. Please select a row.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                        LoadData(); 
                        ClearFields(); 
                    }
                }
                catch (FormatException)
                {
                    MessageBox.Show("Please enter a valid number for Age.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Please select a record to update.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        private void ClearFields()
        {
            txtName.Clear();
            txtAge.Clear();
            cbGender.SelectedIndex = -1;
            txtAddress.Clear();
            txtContact.Clear();
        }

        private void btnVIEW_Click(object sender, EventArgs e)
        {
            LoadData();

        }

        private void btnDELETE_Click(object sender, EventArgs e)
        {
            if (dgvFisherfolk.CurrentRow != null)
            {
                int id = Convert.ToInt32(dgvFisherfolk.CurrentRow.Cells["fisher_id"].Value);
                using (MySqlConnection con = new MySqlConnection(connectionString))
                {
                    con.Open();
                    string query = "DELETE FROM fisherfolk WHERE fisher_id=@id";
                    MySqlCommand cmd = new MySqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Record Deleted Successfully!");
                    LoadData();

                   
                }
                txtName.Clear();
                txtAge.Clear();
                cbGender.SelectedIndex = -1;
                txtAddress.Clear();
                txtContact.Clear();
            }
        }

        private void btnMFG_Click(object sender, EventArgs e)
        {
            Fishing_Gear form4 = new Fishing_Gear();
            form4.Show();
            this.Hide();
        }

        private void btnMFI_Click(object sender, EventArgs e)
        {
            
        }

        private void btnMCR_Click(object sender, EventArgs e)
        {
            Catch_Record form5 = new Catch_Record();
            form5.Show();
            this.Hide();
        }

        private void button7_Click_1(object sender, EventArgs e)
        {
            Fisherfolk_Management form2 = new Fisherfolk_Management();
            form2.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Logout();
        }
        private void Logout()
        {
            DialogResult result = MessageBox.Show(
                "Are you sure you want to logout?",
                "Confirm Logout",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (result == DialogResult.Yes)
            {

                this.Hide();
            }
        }
        private void dgvFisherfolk_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvFisherfolk.Rows[e.RowIndex];
                txtName.Text = row.Cells["full_name"].Value.ToString();
                txtAge.Text = row.Cells["age"].Value.ToString();
                cbGender.Text = row.Cells["gender"].Value.ToString();
                txtAddress.Text = row.Cells["address"].Value.ToString();
                txtContact.Text = row.Cells["contact_no"].Value.ToString();
            }
        }

        private void Fisherfolk__INfo_Form_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Control && e.KeyCode == Keys.S) // Ctrl + S for Add
            {
                btnADD.PerformClick();
            }

            else if (e.Control && e.KeyCode == Keys.U) // Ctrl + U for Update
            {
                btnUPDATE.PerformClick();
            }

            else if (e.Control && e.KeyCode == Keys.D) // Ctrl + D for Delete
            {
                btnDELETE.PerformClick();
            }

            else if (e.Control && e.KeyCode == Keys.V) // Ctrl + V for View
            {
                btnVIEW.PerformClick();
            }
            else if (e.Control && e.KeyCode == Keys.L) // Ctrl + L for Logout
            {
                button1.PerformClick();
            }

            // CTRL + 1 → Fisherfolk Form
            if (e.Control && e.KeyCode == Keys.D1)
            {
                Fisherfolk__INfo_Form fisherForm = new Fisherfolk__INfo_Form();
                fisherForm.Show();
                this.Hide();
            }

            // CTRL + 2 → Fishing Gear Form
            else if (e.Control && e.KeyCode == Keys.D2)
            {
                Fishing_Gear gearForm = new Fishing_Gear();
                gearForm.Show();
                this.Hide();
            }

            // CTRL + 3 → Catch Record Form
            else if (e.Control && e.KeyCode == Keys.D3)
            {
                Catch_Record catchForm = new Catch_Record();
                catchForm.Show();
                this.Hide();
            }

            // CTRL + H → Home/Dashboard
            else if (e.Control && e.KeyCode == Keys.H)
            {
                Fisherfolk_Management dash = new Fisherfolk_Management();
                dash.Show();
                this.Hide();
            }
        }

        private void txtName_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtAge.Focus();
                e.SuppressKeyPress = true;
            }
        }

        private void txtAge_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                cbGender.Focus();
                e.SuppressKeyPress = true;
            }
        }

        private void cbGender_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtAddress.Focus();
                e.SuppressKeyPress = true;
            }
        }

        private void txtAddress_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtContact.Focus();
                e.SuppressKeyPress = true;
            }
        }
    }
}
