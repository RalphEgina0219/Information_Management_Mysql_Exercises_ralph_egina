﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Fisherfolk_Data_Information_System
{
    public partial class Fisherfolk_Management : Form
    {
        public Fisherfolk_Management()
        {
            InitializeComponent();

        }

        private void Fisherfolk_Management_Load(object sender, EventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Fishing_Gear form4 = new Fishing_Gear();
            form4.ShowDialog();
            this.Hide();
        }

        private void button6_Click(object sender, EventArgs e)
        {
        
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            Logout();

        }


        private void button2_Click_1(object sender, EventArgs e)
        {
            Fisherfolk__INfo_Form form3 = new Fisherfolk__INfo_Form();
            form3.Show();
            this.Hide();
        }

        private void btnMCR_Click(object sender, EventArgs e)
        {
            Catch_Record form5 = new Catch_Record();
            form5.Show();
            this.Hide();
        }

        private void Fisherfolk_Management_KeyDown(object sender, KeyEventArgs e)
        {
               // CTRL + 1 → Fisherfolk Form
            if (e.Control && e.KeyCode == Keys.D1)
            {
                Fisherfolk__INfo_Form fisherForm = new Fisherfolk__INfo_Form();
                fisherForm.Show();
                this.Hide();
            }

            // CTRL + 2 → Fishing Gear Form
            else if (e.Control && e.KeyCode == Keys.D2)
            {
                Fishing_Gear gearForm = new Fishing_Gear();
                gearForm.Show();
                this.Hide();
            }

            // CTRL + 3 → Catch Record Form
            else if (e.Control && e.KeyCode == Keys.D3)
            {
                Catch_Record catchForm = new Catch_Record();
                catchForm.Show();
                this.Hide();
            }

            // CTRL + H → Home/Dashboard
            else if (e.Control && e.KeyCode == Keys.H)
            {
                Fisherfolk_Management dash = new Fisherfolk_Management();
                dash.Show();
                this.Hide();
            }
            else if (e.Control && e.KeyCode == Keys.L)
            {
                Logout();
            }


        }
        private void Logout()
        {
            DialogResult result = MessageBox.Show(
                "Are you sure you want to logout?",
                "Confirm Logout",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (result == DialogResult.Yes)
            {
              
                this.Hide(); 
            }
        }
    }
}