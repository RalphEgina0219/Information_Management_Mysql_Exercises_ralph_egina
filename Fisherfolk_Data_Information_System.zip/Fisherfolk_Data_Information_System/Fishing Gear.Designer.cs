﻿namespace Fisherfolk_Data_Information_System
{
    partial class Fishing_Gear
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button7 = new System.Windows.Forms.Button();
            this.btnMCR = new System.Windows.Forms.Button();
            this.btnMFG = new System.Windows.Forms.Button();
            this.btnMFI = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.txtGearName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtType = new System.Windows.Forms.TextBox();
            this.txtOwner = new System.Windows.Forms.TextBox();
            this.txtCondition = new System.Windows.Forms.TextBox();
            this.dgvGears = new System.Windows.Forms.DataGridView();
            this.btnVIEW2 = new System.Windows.Forms.Button();
            this.btnDELETE2 = new System.Windows.Forms.Button();
            this.btnUPDATE2 = new System.Windows.Forms.Button();
            this.btnADD2 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGears)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1592, 59);
            this.panel1.TabIndex = 15;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(50, 9);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(208, 31);
            this.label1.TabIndex = 16;
            this.label1.Text = "Admin Dashboard";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.panel2.Controls.Add(this.button7);
            this.panel2.Controls.Add(this.btnMCR);
            this.panel2.Controls.Add(this.btnMFG);
            this.panel2.Controls.Add(this.btnMFI);
            this.panel2.Controls.Add(this.button1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(297, 762);
            this.panel2.TabIndex = 16;
            // 
            // button7
            // 
            this.button7.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.button7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.button7.FlatAppearance.BorderSize = 0;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold);
            this.button7.ForeColor = System.Drawing.Color.Turquoise;
            this.button7.Image = global::Fisherfolk_Data_Information_System.Properties.Resources.icons8_home_48;
            this.button7.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button7.Location = new System.Drawing.Point(4, 66);
            this.button7.Margin = new System.Windows.Forms.Padding(4);
            this.button7.Name = "button7";
            this.button7.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.button7.Size = new System.Drawing.Size(317, 82);
            this.button7.TabIndex = 10;
            this.button7.Text = "Dashboard";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // btnMCR
            // 
            this.btnMCR.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnMCR.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.btnMCR.FlatAppearance.BorderSize = 0;
            this.btnMCR.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMCR.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMCR.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.btnMCR.Image = global::Fisherfolk_Data_Information_System.Properties.Resources.icons8_paper_501;
            this.btnMCR.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMCR.Location = new System.Drawing.Point(0, 417);
            this.btnMCR.Margin = new System.Windows.Forms.Padding(4);
            this.btnMCR.Name = "btnMCR";
            this.btnMCR.Size = new System.Drawing.Size(317, 82);
            this.btnMCR.TabIndex = 9;
            this.btnMCR.Text = "Manage Catch Records";
            this.btnMCR.UseVisualStyleBackColor = false;
            this.btnMCR.Click += new System.EventHandler(this.btnMCR_Click);
            // 
            // btnMFG
            // 
            this.btnMFG.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.btnMFG.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.btnMFG.FlatAppearance.BorderSize = 0;
            this.btnMFG.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMFG.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMFG.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.btnMFG.Image = global::Fisherfolk_Data_Information_System.Properties.Resources.icons8_gear_50;
            this.btnMFG.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMFG.Location = new System.Drawing.Point(0, 327);
            this.btnMFG.Margin = new System.Windows.Forms.Padding(4);
            this.btnMFG.Name = "btnMFG";
            this.btnMFG.Size = new System.Drawing.Size(317, 82);
            this.btnMFG.TabIndex = 8;
            this.btnMFG.Text = "Manage Fishing Gear";
            this.btnMFG.UseVisualStyleBackColor = false;
            // 
            // btnMFI
            // 
            this.btnMFI.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.btnMFI.FlatAppearance.BorderSize = 0;
            this.btnMFI.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMFI.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMFI.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.btnMFI.Image = global::Fisherfolk_Data_Information_System.Properties.Resources.icons8_fisherman_50;
            this.btnMFI.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMFI.Location = new System.Drawing.Point(0, 237);
            this.btnMFI.Margin = new System.Windows.Forms.Padding(4);
            this.btnMFI.Name = "btnMFI";
            this.btnMFI.Size = new System.Drawing.Size(317, 82);
            this.btnMFI.TabIndex = 7;
            this.btnMFI.Text = "Manage Fisherfolk Info";
            this.btnMFI.UseVisualStyleBackColor = false;
            this.btnMFI.Click += new System.EventHandler(this.btnMFI_Click);
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.button1.Location = new System.Drawing.Point(-20, 667);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(317, 82);
            this.button1.TabIndex = 6;
            this.button1.Text = "LOGOUT";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtGearName
            // 
            this.txtGearName.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.txtGearName.Location = new System.Drawing.Point(464, 110);
            this.txtGearName.Name = "txtGearName";
            this.txtGearName.Size = new System.Drawing.Size(175, 39);
            this.txtGearName.TabIndex = 27;
            this.txtGearName.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtGearName_KeyDown);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(320, 113);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(148, 32);
            this.label3.TabIndex = 28;
            this.label3.Text = "Gear Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(383, 171);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 32);
            this.label2.TabIndex = 29;
            this.label2.Text = "Type:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.label4.Location = new System.Drawing.Point(361, 230);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(97, 32);
            this.label4.TabIndex = 30;
            this.label4.Text = "Owner:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.label5.Location = new System.Drawing.Point(334, 292);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(134, 32);
            this.label5.TabIndex = 31;
            this.label5.Text = "Condition:";
            // 
            // txtType
            // 
            this.txtType.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.txtType.Location = new System.Drawing.Point(464, 168);
            this.txtType.Name = "txtType";
            this.txtType.Size = new System.Drawing.Size(175, 39);
            this.txtType.TabIndex = 32;
            this.txtType.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtType_KeyDown);
            // 
            // txtOwner
            // 
            this.txtOwner.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.txtOwner.Location = new System.Drawing.Point(464, 227);
            this.txtOwner.Name = "txtOwner";
            this.txtOwner.Size = new System.Drawing.Size(175, 39);
            this.txtOwner.TabIndex = 33;
            this.txtOwner.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtOwner_KeyDown);
            // 
            // txtCondition
            // 
            this.txtCondition.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.txtCondition.Location = new System.Drawing.Point(464, 289);
            this.txtCondition.Name = "txtCondition";
            this.txtCondition.Size = new System.Drawing.Size(175, 39);
            this.txtCondition.TabIndex = 34;
            // 
            // dgvGears
            // 
            this.dgvGears.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvGears.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvGears.Location = new System.Drawing.Point(692, 111);
            this.dgvGears.Name = "dgvGears";
            this.dgvGears.RowHeadersWidth = 51;
            this.dgvGears.RowTemplate.Height = 24;
            this.dgvGears.Size = new System.Drawing.Size(830, 651);
            this.dgvGears.TabIndex = 35;
            this.dgvGears.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvGears_CellClick);
            // 
            // btnVIEW2
            // 
            this.btnVIEW2.BackColor = System.Drawing.Color.Aqua;
            this.btnVIEW2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVIEW2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVIEW2.Location = new System.Drawing.Point(344, 566);
            this.btnVIEW2.Name = "btnVIEW2";
            this.btnVIEW2.Size = new System.Drawing.Size(295, 41);
            this.btnVIEW2.TabIndex = 41;
            this.btnVIEW2.Text = "VIEW";
            this.btnVIEW2.UseVisualStyleBackColor = false;
            this.btnVIEW2.Click += new System.EventHandler(this.btnVIEW2_Click);
            // 
            // btnDELETE2
            // 
            this.btnDELETE2.BackColor = System.Drawing.Color.Aqua;
            this.btnDELETE2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDELETE2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDELETE2.Location = new System.Drawing.Point(346, 721);
            this.btnDELETE2.Name = "btnDELETE2";
            this.btnDELETE2.Size = new System.Drawing.Size(295, 41);
            this.btnDELETE2.TabIndex = 40;
            this.btnDELETE2.Text = "DELETE";
            this.btnDELETE2.UseVisualStyleBackColor = false;
            this.btnDELETE2.Click += new System.EventHandler(this.btnDELETE2_Click);
            // 
            // btnUPDATE2
            // 
            this.btnUPDATE2.BackColor = System.Drawing.Color.Aqua;
            this.btnUPDATE2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUPDATE2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUPDATE2.Location = new System.Drawing.Point(346, 641);
            this.btnUPDATE2.Name = "btnUPDATE2";
            this.btnUPDATE2.Size = new System.Drawing.Size(295, 41);
            this.btnUPDATE2.TabIndex = 39;
            this.btnUPDATE2.Text = "UPDATE";
            this.btnUPDATE2.UseVisualStyleBackColor = false;
            this.btnUPDATE2.Click += new System.EventHandler(this.btnUPDATE2_Click);
            // 
            // btnADD2
            // 
            this.btnADD2.BackColor = System.Drawing.Color.Aqua;
            this.btnADD2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnADD2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnADD2.Location = new System.Drawing.Point(346, 486);
            this.btnADD2.Name = "btnADD2";
            this.btnADD2.Size = new System.Drawing.Size(295, 41);
            this.btnADD2.TabIndex = 38;
            this.btnADD2.Text = "ADD";
            this.btnADD2.UseVisualStyleBackColor = false;
            this.btnADD2.Click += new System.EventHandler(this.btnADD2_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(1011, 66);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(278, 31);
            this.label6.TabIndex = 42;
            this.label6.Text = "Fisherfolk\'s Fishing Gear";
            // 
            // Fishing_Gear
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.ClientSize = new System.Drawing.Size(1569, 762);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.btnVIEW2);
            this.Controls.Add(this.btnDELETE2);
            this.Controls.Add(this.btnUPDATE2);
            this.Controls.Add(this.btnADD2);
            this.Controls.Add(this.dgvGears);
            this.Controls.Add(this.txtCondition);
            this.Controls.Add(this.txtOwner);
            this.Controls.Add(this.txtType);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtGearName);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Fishing_Gear";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Fishing_Gear";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Fishing_Gear_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Fishing_Gear_KeyDown);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvGears)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button btnMCR;
        private System.Windows.Forms.Button btnMFG;
        private System.Windows.Forms.Button btnMFI;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtGearName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtType;
        private System.Windows.Forms.TextBox txtOwner;
        private System.Windows.Forms.TextBox txtCondition;
        private System.Windows.Forms.DataGridView dgvGears;
        private System.Windows.Forms.Button btnVIEW2;
        private System.Windows.Forms.Button btnDELETE2;
        private System.Windows.Forms.Button btnUPDATE2;
        private System.Windows.Forms.Button btnADD2;
        private System.Windows.Forms.Label label6;
    }
}