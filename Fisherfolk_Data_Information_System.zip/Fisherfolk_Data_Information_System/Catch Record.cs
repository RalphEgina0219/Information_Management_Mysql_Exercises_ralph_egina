﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Management;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Fisherfolk_Data_Information_System
{
    public partial class Catch_Record : Form
    {
        string connectionString = "server=localhost;database=fisherfolk_db;uid=root;pwd=yourpassword;";

        public Catch_Record()
        {
            InitializeComponent();
        }

        private void DisplayData()
        {
            using (MySqlConnection con = new MySqlConnection(connectionString))
            {
                con.Open();
                MySqlDataAdapter da = new MySqlDataAdapter("SELECT * FROM catch_record", con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvCatch.DataSource = dt;
            }
        }

        private void Catch_Record_Load(object sender, EventArgs e)
        {

        }

        private void btnBack3_Click(object sender, EventArgs e)
        {
           
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Fishing_Gear form4 = new Fishing_Gear();
            form4.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            Fisherfolk__INfo_Form form3 = new Fisherfolk__INfo_Form();
            form3.Show();
            this.Hide();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Fisherfolk_Management form2 = new Fisherfolk_Management();
            form2.Show();
            this.Hide();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Logout();
        }
        private void Logout()
        {
            DialogResult result = MessageBox.Show(
                "Are you sure you want to logout?",
                "Confirm Logout",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (result == DialogResult.Yes)
            {

                this.Hide(); 
            }
        }

        private void btnADD2_Click(object sender, EventArgs e)
        {
            if (txtFisherfolkName.Text == "" || txtFishSpecies.Text == "" || txtWeight.Text == "" || txtLocation.Text == "")
            {
                MessageBox.Show("Please fill all fields!");
                return;
            }

            using (MySqlConnection con = new MySqlConnection(connectionString))
            {
                con.Open();
                string query = "INSERT INTO catch_record (fisher_Name, fish_species, weight_kg, catch_date, location) VALUES (@name, @species, @weight, @date, @location)";
                MySqlCommand cmd = new MySqlCommand(query, con);
                cmd.Parameters.AddWithValue("@name", txtFisherfolkName.Text);
                cmd.Parameters.AddWithValue("@species", txtFishSpecies.Text);
                cmd.Parameters.AddWithValue("@weight", txtWeight.Text);
                cmd.Parameters.AddWithValue("@date", dtpCatchDate.Value.ToString("yyyy-MM-dd"));
                cmd.Parameters.AddWithValue("@location", txtLocation.Text);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Catch record added successfully!");
                DisplayData();
            }
            txtFisherfolkName.Clear();
            txtFishSpecies.Clear();
            txtWeight.Clear();
            txtLocation.Clear();
            dtpCatchDate.Text = DateTime.Now.ToString();

        }

        private void btnUPDATE2_Click(object sender, EventArgs e)
        {
            if (dgvCatch.CurrentRow != null)
            {
                int id = Convert.ToInt32(dgvCatch.CurrentRow.Cells["record_id"].Value);
                using (MySqlConnection con = new MySqlConnection(connectionString))
                {
                    con.Open();
                    string query = "UPDATE catch_record SET fisher_name=@name, fish_species=@species, weight_kg=@weight, catch_date=@date, location=@location WHERE record_id=@id";
                    MySqlCommand cmd = new MySqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@name", txtFisherfolkName.Text);
                    cmd.Parameters.AddWithValue("@species", txtFishSpecies.Text);
                    cmd.Parameters.AddWithValue("@weight", txtWeight.Text);
                    cmd.Parameters.AddWithValue("@date", dtpCatchDate.Value.ToString("yyyy-MM-dd"));
                    cmd.Parameters.AddWithValue("@location", txtLocation.Text);
                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Catch record updated!");
                    DisplayData();
                }
                txtFisherfolkName.Clear();
                txtFishSpecies.Clear();
                txtWeight.Clear();
                txtLocation.Clear();
                dtpCatchDate.Text = DateTime.Now.ToString();
            }
        }

        private void btnDELETE2_Click(object sender, EventArgs e)
        {
            if (dgvCatch.CurrentRow != null)
            {
                int id = Convert.ToInt32(dgvCatch.CurrentRow.Cells["record_id"].Value);
                using (MySqlConnection con = new MySqlConnection(connectionString))
                {
                    con.Open();
                    MySqlCommand cmd = new MySqlCommand("DELETE FROM catch_record WHERE record_id=@id", con);
                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Catch record deleted!");
                    DisplayData();
                }
                txtFisherfolkName.Clear();
                txtFishSpecies.Clear();
                txtWeight.Clear();
                txtLocation.Clear();
                dtpCatchDate.Text = DateTime.Now.ToString();
            }
        }

        private void btnVIEW2_Click(object sender, EventArgs e)
        {
            DisplayData();
        }

        private void txtWeight_TextChanged(object sender, EventArgs e)
        {

        }

        private void dgvCatch_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvCatch.Rows[e.RowIndex];
                txtFisherfolkName.Text = row.Cells["fisher_name"].Value.ToString();
                txtFishSpecies.Text = row.Cells["fish_species"].Value.ToString();
                txtWeight.Text = row.Cells["weight_kg"].Value.ToString();
                txtLocation.Text = row.Cells["location"].Value.ToString();
                dtpCatchDate.Value = Convert.ToDateTime(row.Cells["catch_date"].Value);

                foreach (DataGridViewRow r in dgvCatch.Rows)
                    r.DefaultCellStyle.BackColor = Color.White;

                row.DefaultCellStyle.BackColor = Color.LightBlue;
            }
        }

        private void dgvCatch_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Catch_Record_KeyDown(object sender, KeyEventArgs e)
        {
         

            if (e.Control && e.KeyCode == Keys.S) // Ctrl + S for Add
            {
                btnADD2.PerformClick();
            }

            else if (e.Control && e.KeyCode == Keys.U) // Ctrl + U for Update
            {
                btnUPDATE2.PerformClick();
            }

            else if (e.Control && e.KeyCode == Keys.D) // Ctrl + D for Delete
            {
                btnDELETE2.PerformClick();
            }

            else if (e.Control && e.KeyCode == Keys.V) // Ctrl + V for View
            {
                btnVIEW2.PerformClick();
            }
            else if (e.Control && e.KeyCode == Keys.L) // Ctrl + L for Logout
            {
                button6.PerformClick();
            }

            // CTRL + 1 → Fisherfolk Form
            else if (e.Control && e.KeyCode == Keys.D1)
            {
                Fisherfolk__INfo_Form fisherForm = new Fisherfolk__INfo_Form();
                fisherForm.Show();
                this.Hide();
            }

            // CTRL + 2 → Fishing Gear Form
            else if (e.Control && e.KeyCode == Keys.D2)
            {
                Fishing_Gear gearForm = new Fishing_Gear();
                gearForm.Show();
                this.Hide();
            }

            // CTRL + 3 → Catch Record Form
            else if (e.Control && e.KeyCode == Keys.D3)
            {
                Catch_Record catchForm = new Catch_Record();
                catchForm.Show();
                this.Hide();
            }

            // CTRL + H → Home/Dashboard
            else if (e.Control && e.KeyCode == Keys.H)
            {
                Fisherfolk_Management dash = new Fisherfolk_Management();
                dash.Show();
                this.Hide();
            }

           
        }

        private void txtFisherfolkName_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtFishSpecies.Focus();
                e.SuppressKeyPress = true;
            }
        }

        private void txtFishSpecies_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtWeight.Focus();
                e.SuppressKeyPress = true;
            }
        }

        private void txtLocation_KeyDown(object sender, KeyEventArgs e)
        {
           
        }

        private void txtWeight_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtLocation.Focus();
                e.SuppressKeyPress = true;
            }
        }
    }
}
