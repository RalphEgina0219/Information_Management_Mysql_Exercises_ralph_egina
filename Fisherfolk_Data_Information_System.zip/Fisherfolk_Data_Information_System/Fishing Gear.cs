﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Fisherfolk_Data_Information_System
{
    public partial class Fishing_Gear : Form
    {
        string connectionString = "server=localhost;database=fisherfolk_db;uid=root;pwd=yourpassword;";
        public Fishing_Gear()
        {
            InitializeComponent();
        }
        private void DisplayData()
        {
            using (MySqlConnection con = new MySqlConnection(connectionString))
            {
                con.Open();
                MySqlDataAdapter da = new MySqlDataAdapter("SELECT * FROM fishing_gear", con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvGears.DataSource = dt;
            }
        }

        private void Fishing_Gear_Load(object sender, EventArgs e)
        {

        }

        private void btnBack_Click(object sender, EventArgs e)
        {
        }

        private void btnADD2_Click(object sender, EventArgs e)
        {
            if (txtGearName.Text == "" || txtType.Text == "" || txtOwner.Text == "" || txtCondition.Text == "")
            {
                MessageBox.Show("Please fill all fields!");
                return;
            }

            using (MySqlConnection con = new MySqlConnection(connectionString))
            {
                con.Open();
                string query = "INSERT INTO fishing_gear (gear_name, type, owner, condition_status) VALUES (@name, @type, @owner, @condition)";
                MySqlCommand cmd = new MySqlCommand(query, con);
                cmd.Parameters.AddWithValue("@name", txtGearName.Text);
                cmd.Parameters.AddWithValue("@type", txtType.Text);
                cmd.Parameters.AddWithValue("@owner", txtOwner.Text);
                cmd.Parameters.AddWithValue("@condition", txtCondition.Text);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Fishing gear added successfully!");
                DisplayData();
                ClearFields();
            }

        }

        private void btnUPDATE2_Click(object sender, EventArgs e)
        {
            if (txtGearName.Text == "")
            {
                MessageBox.Show("Select a record to update.");
                return;
            }

            if (dgvGears.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a record from the table to update.");
                return;
            }

            int selectedId = Convert.ToInt32(dgvGears.SelectedRows[0].Cells["id"].Value);

            using (MySqlConnection con = new MySqlConnection(connectionString))
            {
                con.Open();
                string query = "UPDATE fishing_gear SET gear_name=@name, type=@type, owner=@owner, condition_status=@condition WHERE id=@id";
                MySqlCommand cmd = new MySqlCommand(query, con);
                cmd.Parameters.AddWithValue("@id", selectedId);
                cmd.Parameters.AddWithValue("@name", txtGearName.Text);
                cmd.Parameters.AddWithValue("@type", txtType.Text);
                cmd.Parameters.AddWithValue("@owner", txtOwner.Text);
                cmd.Parameters.AddWithValue("@condition", txtCondition.Text);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Fishing gear updated successfully!");
                DisplayData();
                ClearFields();
            }
        }


        private void btnDELETE2_Click(object sender, EventArgs e)
        {
            if (dgvGears.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a record to delete.");
                return;
            }

            int selectedId = Convert.ToInt32(dgvGears.SelectedRows[0].Cells["id"].Value);

            DialogResult result = MessageBox.Show("Are you sure you want to delete this record?", "Confirm Delete", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                using (MySqlConnection con = new MySqlConnection(connectionString))
                {
                    con.Open();
                    string query = "DELETE FROM fishing_gear WHERE id=@id";
                    MySqlCommand cmd = new MySqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@id", selectedId);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Record deleted successfully!");
                    DisplayData();
                    ClearFields();
                }
            }
        }
        private void btnVIEW2_Click(object sender, EventArgs e)
        {
            DisplayData();
        }

        private void btnMFI_Click(object sender, EventArgs e)
        {
            Fisherfolk__INfo_Form form3 = new Fisherfolk__INfo_Form();
            form3.Show();

            this.Hide();
        }

        private void btnMCR_Click(object sender, EventArgs e)
        {
            Catch_Record form5 = new Catch_Record();
            form5.Show();
            this.Hide();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Fisherfolk_Management form2 = new Fisherfolk_Management();
            form2.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
           Logout();
        }
        private void Logout()
        {
            DialogResult result = MessageBox.Show(
                "Are you sure you want to logout?",
                "Confirm Logout",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (result == DialogResult.Yes)
            {

                this.Hide();
            }
        }

        private void dgvGears_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvGears.Rows[e.RowIndex];
                txtGearName.Text = row.Cells["gear_name"].Value.ToString();
                txtType.Text = row.Cells["type"].Value.ToString();
                txtOwner.Text = row.Cells["owner"].Value.ToString();
                txtCondition.Text = row.Cells["condition_status"].Value.ToString();
                
            }
        }
        private void ClearFields()
        {
            txtGearName.Clear();
            txtType.Clear();
            txtOwner.Clear();
            txtCondition.Clear();
        }

        private void Fishing_Gear_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Control && e.KeyCode == Keys.S) // Ctrl + S for Add
            {
                btnADD2.PerformClick();
            }

            else if (e.Control && e.KeyCode == Keys.U) // Ctrl + U for Update
            {
                btnUPDATE2.PerformClick();
            }

            else if (e.Control && e.KeyCode == Keys.D) // Ctrl + D for Delete
            {
                btnDELETE2.PerformClick();
            }

            else if (e.Control && e.KeyCode == Keys.V) // Ctrl + V for View
            {
                btnVIEW2.PerformClick();
            }
            else if (e.Control && e.KeyCode == Keys.L) // Ctrl + L for Logout
            {
                button1.PerformClick();

            }

            // CTRL + 1 → Fisherfolk Form
            if (e.Control && e.KeyCode == Keys.D1)
            {
                Fisherfolk__INfo_Form fisherForm = new Fisherfolk__INfo_Form();
                fisherForm.Show();
                this.Hide();
            }

            // CTRL + 2 → Fishing Gear Form
            else if (e.Control && e.KeyCode == Keys.D2)
            {
                Fishing_Gear gearForm = new Fishing_Gear();
                gearForm.Show();
                this.Hide();
            }

            // CTRL + 3 → Catch Record Form
            else if (e.Control && e.KeyCode == Keys.D3)
            {
                Catch_Record catchForm = new Catch_Record();
                catchForm.Show();
                this.Hide();
            }

            // CTRL + H → Home/Dashboard
            else if (e.Control && e.KeyCode == Keys.H)
            {
                Fisherfolk_Management dash = new Fisherfolk_Management();
                dash.Show();
                this.Hide();
            }
        }

        private void txtGearName_KeyDown(object sender, KeyEventArgs e)
        {

            if (e.KeyCode == Keys.Enter)
            {
                txtType.Focus();
                e.SuppressKeyPress = true;
            }
        }

        private void txtType_KeyDown(object sender, KeyEventArgs e)
        {

            if (e.KeyCode == Keys.Enter)
            {
                txtOwner.Focus();
                e.SuppressKeyPress = true;
            }
        }

        private void txtOwner_KeyDown(object sender, KeyEventArgs e)
        {

            if (e.KeyCode == Keys.Enter)
            {
                txtCondition.Focus();
                e.SuppressKeyPress = true;
            }
        }
    }
}
