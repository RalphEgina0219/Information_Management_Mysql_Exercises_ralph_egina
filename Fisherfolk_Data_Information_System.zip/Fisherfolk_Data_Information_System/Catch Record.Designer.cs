﻿namespace Fisherfolk_Data_Information_System
{
    partial class Catch_Record
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.dgvCatch = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            this.txtFisherfolkName = new System.Windows.Forms.TextBox();
            this.txtFishSpecies = new System.Windows.Forms.TextBox();
            this.txtWeight = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtLocation = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.btnVIEW2 = new System.Windows.Forms.Button();
            this.btnDELETE2 = new System.Windows.Forms.Button();
            this.btnUPDATE2 = new System.Windows.Forms.Button();
            this.btnADD2 = new System.Windows.Forms.Button();
            this.dtpCatchDate = new System.Windows.Forms.DateTimePicker();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCatch)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel1.Controls.Add(this.tableLayoutPanel1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1572, 59);
            this.panel1.TabIndex = 16;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 58);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(298, 704);
            this.tableLayoutPanel1.TabIndex = 11;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(50, 9);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(208, 31);
            this.label1.TabIndex = 16;
            this.label1.Text = "Admin Dashboard";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.panel2.Controls.Add(this.button2);
            this.panel2.Controls.Add(this.button3);
            this.panel2.Controls.Add(this.button4);
            this.panel2.Controls.Add(this.button5);
            this.panel2.Controls.Add(this.button6);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(297, 762);
            this.panel2.TabIndex = 22;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold);
            this.button2.ForeColor = System.Drawing.Color.Turquoise;
            this.button2.Image = global::Fisherfolk_Data_Information_System.Properties.Resources.icons8_home_48;
            this.button2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.Location = new System.Drawing.Point(4, 66);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.button2.Size = new System.Drawing.Size(317, 82);
            this.button2.TabIndex = 10;
            this.button2.Text = "Dashboard";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.button3.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.button3.Image = global::Fisherfolk_Data_Information_System.Properties.Resources.icons8_paper_501;
            this.button3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button3.Location = new System.Drawing.Point(0, 418);
            this.button3.Margin = new System.Windows.Forms.Padding(4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(317, 82);
            this.button3.TabIndex = 9;
            this.button3.Text = "Manage Catch Records";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.button4.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.button4.Image = global::Fisherfolk_Data_Information_System.Properties.Resources.icons8_gear_50;
            this.button4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button4.Location = new System.Drawing.Point(0, 328);
            this.button4.Margin = new System.Windows.Forms.Padding(4);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(317, 82);
            this.button4.TabIndex = 8;
            this.button4.Text = "Manage Fishing Gear";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.button5.FlatAppearance.BorderSize = 0;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.button5.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.button5.Image = global::Fisherfolk_Data_Information_System.Properties.Resources.icons8_fisherman_50;
            this.button5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button5.Location = new System.Drawing.Point(0, 238);
            this.button5.Margin = new System.Windows.Forms.Padding(4);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(317, 82);
            this.button5.TabIndex = 7;
            this.button5.Text = "Manage Fisherfolk Info";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.button6.FlatAppearance.BorderSize = 0;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.button6.Location = new System.Drawing.Point(-20, 665);
            this.button6.Margin = new System.Windows.Forms.Padding(4);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(317, 82);
            this.button6.TabIndex = 6;
            this.button6.Text = "LOGOUT";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // dgvCatch
            // 
            this.dgvCatch.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvCatch.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCatch.Location = new System.Drawing.Point(738, 111);
            this.dgvCatch.Name = "dgvCatch";
            this.dgvCatch.RowHeadersWidth = 51;
            this.dgvCatch.RowTemplate.Height = 24;
            this.dgvCatch.Size = new System.Drawing.Size(783, 651);
            this.dgvCatch.TabIndex = 36;
            this.dgvCatch.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCatch_CellClick);
            this.dgvCatch.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCatch_CellContentClick);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(1044, 66);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(210, 31);
            this.label2.TabIndex = 37;
            this.label2.Text = "Fisherfolk Records";
            // 
            // txtFisherfolkName
            // 
            this.txtFisherfolkName.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.txtFisherfolkName.Location = new System.Drawing.Point(496, 110);
            this.txtFisherfolkName.Name = "txtFisherfolkName";
            this.txtFisherfolkName.Size = new System.Drawing.Size(207, 39);
            this.txtFisherfolkName.TabIndex = 38;
            this.txtFisherfolkName.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtFisherfolkName_KeyDown);
            // 
            // txtFishSpecies
            // 
            this.txtFishSpecies.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.txtFishSpecies.Location = new System.Drawing.Point(496, 177);
            this.txtFishSpecies.Name = "txtFishSpecies";
            this.txtFishSpecies.Size = new System.Drawing.Size(207, 39);
            this.txtFishSpecies.TabIndex = 39;
            this.txtFishSpecies.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtFishSpecies_KeyDown);
            // 
            // txtWeight
            // 
            this.txtWeight.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.txtWeight.Location = new System.Drawing.Point(496, 240);
            this.txtWeight.Name = "txtWeight";
            this.txtWeight.Size = new System.Drawing.Size(207, 39);
            this.txtWeight.TabIndex = 40;
            this.txtWeight.TextChanged += new System.EventHandler(this.txtWeight_TextChanged);
            this.txtWeight.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtWeight_KeyDown);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(304, 113);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(207, 32);
            this.label3.TabIndex = 41;
            this.label3.Text = "Fisherfolk Name:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.label4.Location = new System.Drawing.Point(344, 177);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(156, 32);
            this.label4.TabIndex = 42;
            this.label4.Text = "Fish Species:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.label5.Location = new System.Drawing.Point(323, 247);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(177, 32);
            this.label5.TabIndex = 43;
            this.label5.Text = "Weight(in kg):";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(366, 378);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(113, 31);
            this.label6.TabIndex = 44;
            this.label6.Text = "Location:";
            // 
            // txtLocation
            // 
            this.txtLocation.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLocation.Location = new System.Drawing.Point(496, 371);
            this.txtLocation.Name = "txtLocation";
            this.txtLocation.Size = new System.Drawing.Size(207, 38);
            this.txtLocation.TabIndex = 45;
            this.txtLocation.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtLocation_KeyDown);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(398, 312);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(70, 31);
            this.label7.TabIndex = 47;
            this.label7.Text = "Date:";
            // 
            // btnVIEW2
            // 
            this.btnVIEW2.BackColor = System.Drawing.Color.Aqua;
            this.btnVIEW2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVIEW2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVIEW2.Location = new System.Drawing.Point(348, 557);
            this.btnVIEW2.Name = "btnVIEW2";
            this.btnVIEW2.Size = new System.Drawing.Size(323, 41);
            this.btnVIEW2.TabIndex = 51;
            this.btnVIEW2.Text = "VIEW";
            this.btnVIEW2.UseVisualStyleBackColor = false;
            this.btnVIEW2.Click += new System.EventHandler(this.btnVIEW2_Click);
            // 
            // btnDELETE2
            // 
            this.btnDELETE2.BackColor = System.Drawing.Color.Aqua;
            this.btnDELETE2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDELETE2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDELETE2.Location = new System.Drawing.Point(348, 721);
            this.btnDELETE2.Name = "btnDELETE2";
            this.btnDELETE2.Size = new System.Drawing.Size(323, 41);
            this.btnDELETE2.TabIndex = 50;
            this.btnDELETE2.Text = "DELETE";
            this.btnDELETE2.UseVisualStyleBackColor = false;
            this.btnDELETE2.Click += new System.EventHandler(this.btnDELETE2_Click);
            // 
            // btnUPDATE2
            // 
            this.btnUPDATE2.BackColor = System.Drawing.Color.Aqua;
            this.btnUPDATE2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUPDATE2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUPDATE2.Location = new System.Drawing.Point(348, 641);
            this.btnUPDATE2.Name = "btnUPDATE2";
            this.btnUPDATE2.Size = new System.Drawing.Size(323, 41);
            this.btnUPDATE2.TabIndex = 49;
            this.btnUPDATE2.Text = "UPDATE";
            this.btnUPDATE2.UseVisualStyleBackColor = false;
            this.btnUPDATE2.Click += new System.EventHandler(this.btnUPDATE2_Click);
            // 
            // btnADD2
            // 
            this.btnADD2.BackColor = System.Drawing.Color.Aqua;
            this.btnADD2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnADD2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnADD2.Location = new System.Drawing.Point(350, 477);
            this.btnADD2.Name = "btnADD2";
            this.btnADD2.Size = new System.Drawing.Size(323, 41);
            this.btnADD2.TabIndex = 48;
            this.btnADD2.Text = "ADD";
            this.btnADD2.UseVisualStyleBackColor = false;
            this.btnADD2.Click += new System.EventHandler(this.btnADD2_Click);
            // 
            // dtpCatchDate
            // 
            this.dtpCatchDate.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpCatchDate.Location = new System.Drawing.Point(496, 312);
            this.dtpCatchDate.Name = "dtpCatchDate";
            this.dtpCatchDate.Size = new System.Drawing.Size(206, 38);
            this.dtpCatchDate.TabIndex = 46;
            // 
            // Catch_Record
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.ClientSize = new System.Drawing.Size(1569, 762);
            this.Controls.Add(this.btnVIEW2);
            this.Controls.Add(this.btnDELETE2);
            this.Controls.Add(this.btnUPDATE2);
            this.Controls.Add(this.btnADD2);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.dtpCatchDate);
            this.Controls.Add(this.txtLocation);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtWeight);
            this.Controls.Add(this.txtFishSpecies);
            this.Controls.Add(this.txtFisherfolkName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dgvCatch);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Catch_Record";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Catch_Record";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Catch_Record_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Catch_Record_KeyDown);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCatch)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.DataGridView dgvCatch;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtFisherfolkName;
        private System.Windows.Forms.TextBox txtFishSpecies;
        private System.Windows.Forms.TextBox txtWeight;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtLocation;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnVIEW2;
        private System.Windows.Forms.Button btnDELETE2;
        private System.Windows.Forms.Button btnUPDATE2;
        private System.Windows.Forms.Button btnADD2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.DateTimePicker dtpCatchDate;
    }
}